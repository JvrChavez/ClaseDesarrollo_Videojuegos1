package Ventana1;//En visual studio code necesita llevar package, en consola puede omitirse
//Author Javier Chavez 218212241
public class Main{
    public static void main(String[] args) {
        new Ventana();
    }
}